-- Adminer 3.4.0-dev MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `bi_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idGdProject` varchar(255) DEFAULT NULL,
  `hasImport` tinyint(3) unsigned NOT NULL,
  `isInvited` tinyint(3) unsigned NOT NULL,
  `isExported` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFB` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `idUser` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idFB` (`idFB`),
  KEY `idUser` (`idUser`),
  CONSTRAINT `bi_friends_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `bi_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_objects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFB` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'not set',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFB` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `likes` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idFB` (`idFB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_rAccountsPages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idAccount` int(10) unsigned NOT NULL,
  `idPage` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idPage` (`idPage`),
  KEY `idAccount` (`idAccount`),
  CONSTRAINT `bi_rAccountsPages_ibfk_2` FOREIGN KEY (`idPage`) REFERENCES `bi_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bi_rAccountsPages_ibfk_3` FOREIGN KEY (`idAccount`) REFERENCES `bi_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_rPagesUsers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idPage` int(10) unsigned NOT NULL,
  `idUser` int(10) unsigned NOT NULL,
  `isAdmin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lifetime` int(10) unsigned NOT NULL DEFAULT '0',
  `isLike` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idPage` (`idPage`),
  KEY `idUser` (`idUser`),
  CONSTRAINT `bi_rPagesUsers_ibfk_1` FOREIGN KEY (`idPage`) REFERENCES `bi_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bi_rPagesUsers_ibfk_2` FOREIGN KEY (`idUser`) REFERENCES `bi_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_rStatusMessagesObjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idStatusMessage` int(10) unsigned NOT NULL,
  `idObject` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idStatusMessage` (`idStatusMessage`),
  KEY `idObject` (`idObject`),
  CONSTRAINT `bi_rStatusMessagesObjects_ibfk_1` FOREIGN KEY (`idStatusMessage`) REFERENCES `bi_statusMessages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bi_rStatusMessagesObjects_ibfk_2` FOREIGN KEY (`idObject`) REFERENCES `bi_objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_statusMessages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFB` varchar(255) NOT NULL,
  `story` varchar(255) DEFAULT NULL,
  `message` text,
  `type` text,
  `idUser` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `comments` int(10) unsigned NOT NULL,
  `action` enum('like','unlike','friends','app') DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idUser` (`idUser`),
  CONSTRAINT `bi_statusMessages_ibfk_3` FOREIGN KEY (`idUser`) REFERENCES `bi_users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bi_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFB` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `influence` int(10) unsigned NOT NULL DEFAULT '0',
  `accessToken` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idFB` (`idFB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2012-11-15 14:10:28
